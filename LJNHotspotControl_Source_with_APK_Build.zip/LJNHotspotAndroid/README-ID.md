# LJN Hotspot Control Android

Proyek Android Studio pembungkus WebView untuk situs:
https://ljnpoint.online/kick/

## Fitur
- Membuka situs LJN Hotspot Control langsung di aplikasi Android.
- Mempertahankan cookie sesi login admin di WebView.
- Progress bar oranye saat halaman dimuat.
- Tombol Back Android menavigasi halaman sebelumnya.
- URL HTTPS eksternal dibuka di browser, bukan di dalam aplikasi.
- Sertifikat SSL tetap divalidasi; aplikasi tidak melewati error sertifikat.

## Cara build APK
1. Ekstrak ZIP.
2. Buka Android Studio versi terbaru.
3. Pilih **Open** lalu pilih folder `LJNHotspotAndroid`.
4. Tunggu Gradle Sync selesai. Jika diminta, gunakan JDK 17 dan Android SDK Platform 35.
5. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. APK debug biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.

## Catatan
- Paket ini adalah source project Android Studio, bukan APK yang sudah dikompilasi.
- Aplikasi memuat website yang sudah ada; fitur backend tetap berjalan di server web.
- Situs harus bisa diakses melalui HTTPS yang valid. Aplikasi tidak menonaktifkan pemeriksaan sertifikat.
- Untuk rilis publik, buat APK release yang ditandatangani di Android Studio.

## Build APK melalui GitHub Actions (tanpa memasang Android Studio di komputer)
1. Buat repository GitHub baru lalu unggah seluruh isi folder proyek ini.
2. Buka tab **Actions** dan jalankan workflow **Build Android APK** (Run workflow), atau lakukan push ke branch `main`/`master`.
3. Setelah workflow berhasil, buka hasil workflow dan unduh artifact **LJN-Hotspot-Control-debug-apk**.
4. Ekstrak artifact ZIP untuk mendapatkan `app-debug.apk`.

APK debug untuk instalasi/uji coba, bukan APK release bertanda tangan untuk publikasi Play Store.
